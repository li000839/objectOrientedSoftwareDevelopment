public OtherClass {
}
