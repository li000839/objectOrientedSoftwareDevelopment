import bagel.AbstractGame;
import bagel.Input;

public class ShadowLife extends AbstractGame {
    @Override
    protected void update(Input input) {
    }

    public static void main(String[] args) {
        new ShadowLife().run();
    }
}
